
// Connect to Phantom Wallet
async function connectWallet() {
  if (window.solana && window.solana.isPhantom) {
    try {
      const resp = await window.solana.connect();
      document.getElementById("wallet-address").innerText = "Connected: " + resp.publicKey.toString();
    } catch (err) {
      console.error("Connection failed:", err);
    }
  } else {
    alert("Phantom Wallet not found. Please install it.");
  }
}

window.addEventListener("DOMContentLoaded", () => {
  const connectBtn = document.getElementById("connect-btn");
  if (connectBtn) {
    connectBtn.addEventListener("click", connectWallet);
  }
});
