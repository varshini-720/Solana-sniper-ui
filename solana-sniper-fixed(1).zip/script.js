
document.getElementById("connect").addEventListener("click", async () => {
  if (window.solana && window.solana.isPhantom) {
    try {
      const resp = await window.solana.connect();
      alert("Connected wallet: " + resp.publicKey.toString());
    } catch (err) {
      alert("Connection failed: " + err.message);
    }
  } else {
    alert("Phantom wallet not found. Please install it.");
  }
});
